<?php
use yii\web\Request;
use yii\web\Response;
use yii\web\View;

   return $this->goBack();
<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Statistik';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-statistic">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        This is the Statictics page. You may modify the following file to customize its content:
    </p>

    <code><?= __FILE__ ?></code>
</div>

$(function(){
  $(".button-collapse").sideNav();
});

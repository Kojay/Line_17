<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=hwausleihe',
    'username' => 'root',
    'password' => 'admin',
    'charset' => 'utf8',
];

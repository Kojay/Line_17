<?php
namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\SqlDataProvider;

/**
 * ContactForm is the model behind the contact form.
 */
class QueryForm extends Model
{
    private $dataProvider;

     public function getDataArtikel()
    {
        $dataProvider = new SqlDataProvider([
        'sql' => 'SELECT * FROM lv_article',
            
        'sort' => [
        'attributes' => [
            'articleName' => [
                'asc' => ['articleName' => SORT_ASC],
                'desc' => ['articleName' => SORT_DESC],
                //'default' => SORT_DESC,
                'label' => 'Post Title',
            ],
            /*'population' => [
                'asc' => ['population' => SORT_ASC],
                'desc' => ['population' => SORT_DESC],
                'default' => SORT_DESC,
                'label' => 'Name',
            ],*/
			'created_on'
        ],
    ],
            'pagination' => [
	    'pagesize' => 80,
    ],

        ]);
        return $dataProvider;
    }
      
   /* public function getDataAllfaelligeAusleihungen()
    {
        $dataProvider = new SqlDataProvider([
        'sql' => 'SELECT * FROM lv_article ',
            
        'sort' => [
        'attributes' => [
            'name' => [
                'asc' => ['name' => SORT_ASC],
                'desc' => ['name' => SORT_DESC],
                //'default' => SORT_DESC,
                'label' => 'Post Title',
            ],
            'population' => [
                'asc' => ['population' => SORT_ASC],
                'desc' => ['population' => SORT_DESC],
                'default' => SORT_DESC,
                'label' => 'Name',
            ],
			'created_on'
        ],
    ],
            'pagination' => [
	    'pagesize' => 80,
    ],

        ]);
        return $dataProvider;
    }
    
    public function getDataBaldfaelligeAusleihungen()
    {
        $dataProvider = new SqlDataProvider([
        'sql' => 'SELECT * FROM lv_article ',
            
        'sort' => [
        'attributes' => [
            'name' => [
                'asc' => ['name' => SORT_ASC],
                'desc' => ['name' => SORT_DESC],
                //'default' => SORT_DESC,
                'label' => 'Post Title',
            ],
            'population' => [
                'asc' => ['population' => SORT_ASC],
                'desc' => ['population' => SORT_DESC],
                'default' => SORT_DESC,
                'label' => 'Name',
            ],
			'created_on'
        ],
    ],
            'pagination' => [
	    'pagesize' => 80,
    ],

        ]);
        return $dataProvider;
    }*/
}



